# -*- coding: utf-8 -*-
"""
    plnt
    ~~~~

    Noun. plnt (plant) -- a planet application that sounds like a herb.

    :copyright: (c) 2009 by the Werkzeug Team, see AUTHORS for more details.
    :license: BSD.
"""
from plnt.webapp import Plnt
